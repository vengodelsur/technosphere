#!/bin/bash

python ./broder_shingles.py "$@"
